# Autonomous Trading

Version: 1.0.0-real

Autonomous live trading is **not enabled** in this milestone. Manual live submit/cancel are the priority and are implemented only through the guarded manual control plane.

Autonomous paths remain off by default and deterministic-signal based. Dry-run and fake-adapter modes may be used for local workflow validation. No background scheduler starts automatically. Autonomous live trading must not run unless a future release explicitly proves all strategy, market, token, budget, kill-switch, execution-quality, and audit gates.
