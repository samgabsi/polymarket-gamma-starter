# Live Reconciliation

Version: 1.0.0-real

Reconciliation is read-only. It compares local live order ledger events against local state and, when a future operator explicitly enables safe remote checks, adapter order/open-order status. Reconciliation never submits, cancels, or mutates exchange state.

Without credentials or network enablement it degrades to local-only status.
