# Live Order Ledger

Version: 1.0.0-real

The live order ledger derives local audit events from manual execution attempts. It records blocked attempts, fake-local events, and real adapter results when they occur. It stores response hashes and redacted summaries, not private keys or raw secrets.

Real submit/cancel events include `network_attempted`, `signed_payload_present`, `exchange_acknowledgement_present`, `exchange_order_id` where available, and redacted response metadata. Fake-local receipts remain simulations and are not exchange acknowledgements.
